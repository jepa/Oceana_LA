
Downloaded 03-September-2018

CATCH DATA, STOCK STATUS, MARINE TROPHIC INDEX, MULTINATIONAL FOOTPRINT, AND ASSOCIATED METHODS

Data version 47.0

Please note that the data (‘reconstructed data’) are a combination of official reported data and reconstructed estimates of unreported data (including major discards).

Official reported data are mainly extracted from the Food and Agriculture Organization of the United Nations (FAO) FishStat database (found here: http://www.fao.org/fishery/statistics/en).

MARICULTURE

Data version 1.0

Users are encouraged to report errors and omissions, preferably with details to enable rapid corrections. Please contact http://www.seaaroundus.org/contact/

Please cite these data using the following guidelines: http://www.seaaroundus.org/citation-policy/

These data are licensed to the public under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International Public License.

Description is here: http://creativecommons.org/licenses/by-nc-sa/4.0/

Full text is here: http://creativecommons.org/licenses/by-nc-sa/4.0/legalcode

